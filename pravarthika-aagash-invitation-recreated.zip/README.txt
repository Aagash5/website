Pravarthika & Aagash — Invitation Website
===========================================

Included
--------
- index.html
- assets/01-opening.svg
- assets/02-nichayadhartham.svg
- assets/03-registration.svg
- assets/04-rsvp.svg
- assets/05-closing.svg
- rsvp-google-apps-script.gs

Event
-----
Sunday, 24 January 2027
9:00 AM onwards
Nichayadhartham followed by Marriage Registration
Dwaraka Indian Vegetarian Restaurant, Bambalapitiya, Colombo, Sri Lanka

RSVP
----
The website works in preview mode immediately.
To save RSVPs into Google Sheets, deploy rsvp-google-apps-script.gs as a Web App
and paste the resulting /exec URL into RSVP_ENDPOINT near the bottom of index.html.

Artwork replacement
-------------------
The scene artwork is intentionally separated from the code.
To use your exact final artwork, replace the five SVG files in /assets with your
final images and update the five asset references in index.html if the extensions differ.

Hosting
-------
This is a static site. Upload the folder to Replit, GitHub Pages, Netlify, Vercel,
Cloudflare Pages, or any normal web host. The entry file is index.html.
