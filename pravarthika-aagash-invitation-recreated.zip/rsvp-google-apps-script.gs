/**
 * Google Apps Script endpoint for the invitation RSVP.
 * Sheet columns: Timestamp | Family Name | Total Guests
 *
 * 1. Create a Google Sheet.
 * 2. Extensions > Apps Script.
 * 3. Paste this file.
 * 4. Replace SHEET_NAME if required.
 * 5. Deploy > New deployment > Web app.
 * 6. Execute as: Me. Who has access: Anyone.
 * 7. Paste the /exec URL into RSVP_ENDPOINT in index.html.
 */
const SHEET_NAME = 'RSVP';

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    const familyName = String(data.familyName || '').trim();
    const totalGuests = Number(data.totalGuests);

    if (!familyName || !Number.isInteger(totalGuests) || totalGuests < 1 || totalGuests > 15) {
      return json({ ok: false, message: 'Invalid RSVP details.' });
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow(['Timestamp', 'Family Name', 'Total Guests']);
    }

    sheet.appendRow([new Date(), familyName, totalGuests]);
    return json({ ok: true });
  } catch (err) {
    return json({ ok: false, message: String(err) });
  }
}

function json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
